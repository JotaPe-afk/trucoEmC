// client.c
// compile: gcc client.c truco.c -o client.exe -lws2_32 -Wall -Wextra -g

#include "truco.h"

int main() {
    SetConsoleOutputCP(CP_UTF8);
    setlocale(LC_ALL, "en_US.UTF-8");

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) { printf("WSAStartup falhou\n"); return 1; }

    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == INVALID_SOCKET) { printf("Erro socket\n"); WSACleanup(); return 1; }

    struct sockaddr_in server;
    memset(&server,0,sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORTA);
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Conectando ao servidor...\n");
    if (connect(sock, (struct sockaddr*)&server, sizeof(server)) == SOCKET_ERROR) {
        printf("Falha na conexão. Rode o servidor primeiro.\n");
        closesocket(sock); WSACleanup(); return 1;
    }
    printf("Conectado!\n");

    Jogador local;
    local.pontos = 0; local.rodadaGanha = 0;
    strncpy(local.nome, "ClienteLocal", sizeof(local.nome)-1);

    char buf[MAX_BUF];
    int bytes;

    // esperar MAO e VIRA iniciais
    // We'll loop until receiving both MAO and VIRA
    int gotMao = 0, gotVira = 0;
    while (!(gotMao && gotVira)) {
        bytes = recv(sock, buf, sizeof(buf)-1, 0);
        if (bytes <= 0) { printf("Servidor encerrou\n"); closesocket(sock); WSACleanup(); return 1; }
        buf[bytes]='\0';
        if (strncmp(buf,"MAO:",4) == 0) {
            int v0,v1,v2; char n0[16], n1[16], n2[16];
            if (sscanf(buf+4,"%d:%15[^:]:%d:%15[^:]:%d:%15s", &v0,n0,&v1,n1,&v2,n2) == 6) {
                local.mao[0].valor = v0; strncpy(local.mao[0].naipe, n0, sizeof(local.mao[0].naipe)-1); strncpy(local.mao[0].nome, valor_para_nome(v0), sizeof(local.mao[0].nome)-1); local.mao[0].ativo=1;
                local.mao[1].valor = v1; strncpy(local.mao[1].naipe, n1, sizeof(local.mao[1].naipe)-1); strncpy(local.mao[1].nome, valor_para_nome(v1), sizeof(local.mao[1].nome)-1); local.mao[1].ativo=1;
                local.mao[2].valor = v2; strncpy(local.mao[2].naipe, n2, sizeof(local.mao[2].naipe)-1); strncpy(local.mao[2].nome, valor_para_nome(v2), sizeof(local.mao[2].nome)-1); local.mao[2].ativo=1;
                gotMao = 1;
                printf("Recebi minha mão do servidor.\n");
                mostrarMao(&local, 1);
            }
        } else if (strncmp(buf,"VIRA:",5) == 0) {
            int vv; char vn[16];
            if (sscanf(buf+5, "%d:%15s", &vv, vn) == 2) {
                printf("\n=== VIRA RECEBIDO ===\n");
                printf("Valor: %d  Naipe: %s\n", vv, vn);
                gotVira = 1;
            }
        } else {
            printf("Msg inicial: %s\n", buf);
        }
    }

    int pontosRodadaLocal = 1;

    // loop principal: receber mensagens e reagir
    while ((bytes = recv(sock, buf, sizeof(buf)-1, 0)) > 0) {
        buf[bytes] = '\0';
        if (strncmp(buf, "SUA_VEZ", 7) == 0) {
            // Sua vez: mostrar mão e perguntar ação
            printf("\n=== SUA VEZ ===\n");
            mostrarMao(&local, 1);
            printf("[1] Jogar carta   [2] Pedir Truco\n");
            int op = lerEscolhaValidada(1,2);
            if (op == 2) {
                // pedir truco (iniciador = 1)
                int r = negociarTruco(sock, &pontosRodadaLocal, NULL, 1, 1); // jogadores not needed locally for negotiation in client demo
                if (r == 3) { printf("Mão finalizada por corrida.\n"); continue; }
            }
            // jogar carta
            printf("Escolha carta (1-%d): ", CARTAS_POR_JOGADOR);
            int escolha = lerEscolhaValidada(1, CARTAS_POR_JOGADOR) - 1;
            while (!local.mao[escolha].ativo) {
                printf("Carta inválida/desativada. Escolha outra.\n");
                escolha = lerEscolhaValidada(1, CARTAS_POR_JOGADOR) - 1;
            }
            Carta c = local.mao[escolha];
            local.mao[escolha].ativo = 0;
            char out[MAX_BUF];
            snprintf(out, sizeof(out), "CARTA:%d:%s:%d", c.valor, c.naipe, escolha+1);
            send(sock, out, (int)strlen(out), 0);
            printf("Você jogou: %d %s\n", c.valor, c.naipe);
        }
        else if (strncmp(buf, "CARTA:",6) == 0) {
            // servidor jogou
            int val; char naipe[16]; int idx;
            if (sscanf(buf+6, "%d:%15[^:]:%d", &val, naipe, &idx) == 3) {
                printf("Servidor jogou: %d %s\n", val, naipe);
                // Agora é sua vez (server might expect response) - loop will receive SUA_VEZ or not depending on server design.
            }
        }
        else if (strncmp(buf, "CARTA_OPONENTE:",15) == 0) {
            printf("Recebi carta do oponente: %s\n", buf+15);
        }
        else if (strncmp(buf, "TRUCO_RESPOSTA:",14) == 0) {
            int resp; if (sscanf(buf+14,"%d",&resp)==1) {
                if (resp == 1) { pontosRodadaLocal = (pontosRodadaLocal==1?3:pontosRodadaLocal); printf("Truco aceito pelo servidor\n"); }
                else if (resp == 3) printf("Servidor correu (você vence a rodada)\n");
            }
        }
        else if (strncmp(buf, "PLACAR:",7) == 0) {
            int p1,p2; if (sscanf(buf+7,"%d:%d",&p1,&p2)==2) {
                printf("\nPLACAR atualizado: Servidor=%d  Você=%d\n", p1, p2);
            }
        }
        else if (strncmp(buf, "FIM:",4) == 0) {
            int v; if (sscanf(buf+4,"%d",&v)==1) {
                if (v==1) printf("\nParabéns! Você ganhou o jogo!\n");
                else printf("\nServidor venceu o jogo.\n");
                break;
            }
        } else {
            printf("Recebido: %s\n", buf);
        }
    }

    printf("Conexão encerrada. Pressione ENTER para sair...\n");
    getchar();
    closesocket(sock);
    WSACleanup();
    return 0;
}
