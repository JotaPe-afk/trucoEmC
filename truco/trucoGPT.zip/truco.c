#include "truco.h"

Carta baralho[NUM_CARTAS];
Carta vira;
int manilha_valor = 0;
int pontosRodada = 1;

static const char *naipes_utf8[4] = { "♥", "♦", "♣", "♠" };

/* helpers */
const char *valor_para_nome(int valor) {
    switch (valor) {
        case 1: return "A";
        case 2: return "2";
        case 3: return "3";
        case 4: return "4";
        case 5: return "5";
        case 6: return "6";
        case 7: return "7";
        case 8: return "Q";
        case 9: return "J";
        case 10: return "K";
        default: return "?";
    }
}
const char *naipe_padrao(int idx) { return naipes_utf8[idx % 4]; }

/* baralho */
void iniciandoBaralho() {
    int idx = 0;
    for (int n = 0; n < 4; ++n) {
        for (int v = 1; v <= 10; ++v) {
            strncpy(baralho[idx].nome, valor_para_nome(v), sizeof(baralho[idx].nome)-1);
            strncpy(baralho[idx].naipe, naipe_padrao(n), sizeof(baralho[idx].naipe)-1);
            baralho[idx].valor = v;
            baralho[idx].ativo = 0;
            idx++;
        }
    }
}

void embaralharBaralho() {
    srand((unsigned)time(NULL));
    for (int i = 0; i < NUM_CARTAS; ++i) {
        int j = rand() % NUM_CARTAS;
        Carta t = baralho[i];
        baralho[i] = baralho[j];
        baralho[j] = t;
    }
}

Carta distribuirCarta() {
    for (;;) {
        int idx = rand() % NUM_CARTAS;
        if (!baralho[idx].ativo) {
            baralho[idx].ativo = 1;
            return baralho[idx];
        }
    }
}

void distribuirMao(Jogador jogadores[2]) {
    for (int p = 0; p < 2; ++p) {
        for (int c = 0; c < CARTAS_POR_JOGADOR; ++c) {
            jogadores[p].mao[c] = distribuirCarta();
            jogadores[p].mao[c].ativo = 1;
        }
        jogadores[p].rodadaGanha = 0;
    }
}

/* ascii art */
void gerar_arte_carta(Carta c) {
    printf("┌─────────┐\n");
    printf("│ %-2s      │\n", c.nome);
    printf("│    %s    │\n", c.naipe);
    printf("│       %-2s │\n", c.nome);
    printf("└─────────┘\n");
}

void mostrarMao(Jogador *j, int jogadorNum) {
    printf("\nMão do Jogador %d (%s):\n", jogadorNum + 1, j->nome);
    for (int i = 0; i < CARTAS_POR_JOGADOR; i++) {
        if (j->mao[i].ativo) {
            printf("[%d]\n", i+1);
            gerar_arte_carta(j->mao[i]);
        } else {
            printf("[%d] (já jogada)\n", i+1);
        }
    }
}

/* define vira e manilha */
void definirVira() {
    vira = distribuirCarta();
    // manilha = valor seguinte (circular entre 1..10)
    manilha_valor = (vira.valor % 10) + 1;
    printf("\n=== Vira ===\n");
    gerar_arte_carta(vira);
    printf("Manilha (valor): %d (%s)\n", manilha_valor, valor_para_nome(manilha_valor));
}

/* comparar cartas (considera manilha) */
int compararCartas(Carta c1, Carta c2) {
    int c1man = (c1.valor == manilha_valor);
    int c2man = (c2.valor == manilha_valor);
    if (c1man && !c2man) return 1;
    if (!c1man && c2man) return -1;
    if (c1.valor > c2.valor) return 1;
    if (c1.valor < c2.valor) return -1;
    // se empate por valor e não manilha, desempata por naipe order OUROS < ESPADAS < COPAS < PAUS
    // como naipe é string, deduzemos por sequência naipes_utf8
    int idx1=-1, idx2=-1;
    for (int i=0;i<4;i++) {
        if (strcmp(c1.naipe, naipes_utf8[i])==0) idx1=i;
        if (strcmp(c2.naipe, naipes_utf8[i])==0) idx2=i;
    }
    if (idx1 > idx2) return 1;
    if (idx1 < idx2) return -1;
    return 0;
}

/* leitura validada */
int lerEscolhaValidada(int min, int max) {
    int escolha;
    int c;
    while (1) {
        if (scanf("%d", &escolha) != 1) {
            while ((c = getchar()) != '\n' && c != EOF);
            printf("Entrada inválida. Tente novamente: ");
            continue;
        }
        while ((c = getchar()) != '\n' && c != EOF);
        if (escolha < min || escolha > max) {
            printf("Escolha deve estar entre %d e %d. Tente novamente: ", min, max);
            continue;
        }
        return escolha;
    }
}

/* negociarTruco: lógica simétrica para cliente/servidor
   Mensagens trocadas:
   - TRUCO_PEDIDO:<valor>:<challenger>
   - TRUCO_AUMENTOU:<valor>:<challenger>
   - TRUCO_RESPOSTA:<1|2|3>   (1=aceitar,2=aumentar,3=correr)
   - TRUCO_CORREU_FIM:<j>:<pts>
*/
int negociarTruco(SOCKET s, int *pontosRodada, Jogador jogadores[2], int iniciador, int indexLocal) {
    int valores[5] = {1,3,6,9,12};
    int idx = 0;
    for (int i=0;i<5;i++) if (valores[i]==*pontosRodada) { idx=i; break; }
    if (idx >= 4) { return 0; } // já no máximo

    int proximo = valores[idx+1];
    char buf[MAX_BUF];

    // se local iniciou, envia pedido
    if (indexLocal == iniciador) {
        snprintf(buf, sizeof(buf), "TRUCO_PEDIDO:%d:%d", proximo, iniciador);
        send(s, buf, (int)strlen(buf), 0);
    }

    // loop de negociação
    while (1) {
        int bytes = recv(s, buf, sizeof(buf)-1, 0);
        if (bytes <= 0) return 0;
        buf[bytes] = '\0';

        if (strncmp(buf, "TRUCO_PEDIDO:", 13) == 0) {
            int valorPedido, challenger;
            if (sscanf(buf+13, "%d:%d", &valorPedido, &challenger) < 2) continue;
            printf("\nOponente pediu truco para %d pontos.\n", valorPedido);
            printf("Responder: [1] Aceitar [2] Aumentar [3] Correr\n");
            int resp = lerEscolhaValidada(1,3);
            char out[MAX_BUF];
            snprintf(out, sizeof(out), "TRUCO_RESPOSTA:%d", resp);
            send(s, out, (int)strlen(out), 0);
            if (resp == 1) { *pontosRodada = valorPedido; return 1; }
            if (resp == 3) { jogadores[challenger].pontos += *pontosRodada; return 3; }
            if (resp == 2) {
                int idxv=0; for (int i=0;i<5;i++) if (valores[i]==valorPedido) { idxv=i; break; }
                if (idxv < 4) {
                    int novo = valores[idxv+1];
                    int novoChall = 1 - challenger;
                    snprintf(out, sizeof(out), "TRUCO_AUMENTOU:%d:%d", novo, novoChall);
                    send(s, out, (int)strlen(out), 0);
                }
            }
        }
        else if (strncmp(buf, "TRUCO_AUMENTOU:", 14) == 0) {
            int novo, chall;
            if (sscanf(buf+14, "%d:%d", &novo, &chall) < 2) continue;
            printf("\nOponente aumentou para %d pontos.\n", novo);
            printf("Responder: [1] Aceitar [2] Aumentar [3] Correr\n");
            int resp = lerEscolhaValidada(1,3);
            char out[MAX_BUF];
            snprintf(out, sizeof(out), "TRUCO_RESPOSTA:%d", resp);
            send(s, out, (int)strlen(out), 0);
            if (resp == 1) { *pontosRodada = novo; return 1; }
            if (resp == 3) { jogadores[chall].pontos += *pontosRodada; return 3; }
            if (resp == 2) {
                int idxv=0; for (int i=0;i<5;i++) if (valores[i]==novo) { idxv=i; break; }
                if (idxv < 4) {
                    int proximo2 = valores[idxv+1];
                    int novoChall = 1 - chall;
                    snprintf(out, sizeof(out), "TRUCO_AUMENTOU:%d:%d", proximo2, novoChall);
                    send(s, out, (int)strlen(out), 0);
                }
            }
        }
        else if (strncmp(buf, "TRUCO_RESPOSTA:", 14) == 0) {
            int resp = 0;
            if (sscanf(buf+14, "%d", &resp) < 1) continue;
            if (resp == 1) { *pontosRodada = proximo; return 1; }
            if (resp == 3) { jogadores[iniciador].pontos += *pontosRodada; return 3; }
            if (resp == 2) continue;
        }
        else if (strncmp(buf, "TRUCO_CORREU_FIM:", 16) == 0) {
            int j, pts;
            if (sscanf(buf+16, "%d:%d", &j, &pts) == 2) {
                jogadores[j].pontos = pts;
                return 3;
            }
        }
    }
}
