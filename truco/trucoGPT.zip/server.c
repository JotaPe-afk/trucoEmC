// server.c
// compile: gcc server.c truco.c -o server.exe -lws2_32 -Wall -Wextra -g

#include "truco.h"

int main() {
    /* UTF-8 console */
    SetConsoleOutputCP(CP_UTF8);
    setlocale(LC_ALL, "en_US.UTF-8");

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) { printf("WSAStartup falhou\n"); return 1; }

    SOCKET listenSock = socket(AF_INET, SOCK_STREAM, 0);
    if (listenSock == INVALID_SOCKET) { printf("Erro socket\n"); WSACleanup(); return 1; }

    struct sockaddr_in addr;
    memset(&addr,0,sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(PORTA);

    if (bind(listenSock, (struct sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) { printf("Erro bind\n"); closesocket(listenSock); WSACleanup(); return 1; }
    if (listen(listenSock,1) == SOCKET_ERROR) { printf("Erro listen\n"); closesocket(listenSock); WSACleanup(); return 1; }

    printf("Aguardando conexão do cliente na porta %d...\n", PORTA);
    struct sockaddr_in clientAddr;
    int clientLen = sizeof(clientAddr);
    SOCKET clientSock = accept(listenSock, (struct sockaddr*)&clientAddr, &clientLen);
    if (clientSock == INVALID_SOCKET) { printf("Accept falhou\n"); closesocket(listenSock); WSACleanup(); return 1; }
    printf("Cliente conectado!\n");

    /* prepara jogadores */
    Jogador jogadores[2];
    strncpy(jogadores[0].nome, "Servidor", sizeof(jogadores[0].nome)-1);
    strncpy(jogadores[1].nome, "Cliente", sizeof(jogadores[1].nome)-1);
    jogadores[0].pontos = jogadores[1].pontos = 0;

    /* iniciar baralho, distribuir */
    iniciandoBaralho();
    embaralharBaralho();
    distribuirMao(jogadores);
    definirVira(); // define global vira & manilha_valor

    /* enviar MAO para cliente (valores e naipes) */
    char buf[MAX_BUF];
    snprintf(buf, sizeof(buf), "MAO:%d:%s:%d:%s:%d:%s",
        jogadores[1].mao[0].valor, jogadores[1].mao[0].naipe,
        jogadores[1].mao[1].valor, jogadores[1].mao[1].naipe,
        jogadores[1].mao[2].valor, jogadores[1].mao[2].naipe);
    send(clientSock, buf, (int)strlen(buf), 0);

    /* também enviar VIRA para cliente */
    char vmsg[MAX_BUF];
    snprintf(vmsg, sizeof(vmsg), "VIRA:%d:%s", vira.valor, vira.naipe);
    send(clientSock, vmsg, (int)strlen(vmsg), 0);

    /* jogo principal */
    int pontosRodadaLocal = 1;
    int mano = 1;
    while (jogadores[0].pontos < MAX_PONTOS && jogadores[1].pontos < MAX_PONTOS) {
        printf("\n=== MÃO %d (placar S:%d C:%d) ===\n", mano, jogadores[0].pontos, jogadores[1].pontos);
        // Reiniciar variável de quem ganha rodadas
        jogadores[0].rodadaGanha = jogadores[1].rodadaGanha = 0;
        pontosRodadaLocal = 1;

        // 3 rodadas (melhor de 3)
        for (int rodada = 1; rodada <= 3 && jogadores[0].rodadaGanha < 2 && jogadores[1].rodadaGanha < 2; ++rodada) {
            printf("\n-- RODADA %d -- Valor atual da rodada: %d\n", rodada, pontosRodadaLocal);

            // decidir ordem: alterna quem começa cada mão? Em Truco, quem é mão inicia; para simplicidade, servidor começa sempre nesta demo.
            // Para permitir truco a qualquer momento, servidor e cliente podem enviar TRUCO_PEDIDO antes de jogar.
            // Primeiro: servidor escolhe (é jogador 0). Mostra mão local.
            mostrarMao(&jogadores[0], 0);

            printf("Servidor: escolha: [1] Jogar carta  [2] Pedir Truco\n");
            int op = lerEscolhaValidada(1,2);
            if (op == 2) {
                int r = negociarTruco(clientSock, &pontosRodadaLocal, jogadores, 0, 0);
                if (r == 3) { printf("Truco finalizou mão (corrida)."); break; }
            }

            int escolha = lerEscolhaValidada(1, CARTAS_POR_JOGADOR) - 1;
            while (!jogadores[0].mao[escolha].ativo) {
                printf("Carta indisponível, escolha outra.\n");
                escolha = lerEscolhaValidada(1, CARTAS_POR_JOGADOR) - 1;
            }
            Carta c1 = jogadores[0].mao[escolha];
            jogadores[0].mao[escolha].ativo = 0;

            // enviar carta ao cliente
            char sendc[MAX_BUF];
            snprintf(sendc, sizeof(sendc), "CARTA:%d:%s:%d", c1.valor, c1.naipe, escolha+1);
            send(clientSock, sendc, (int)strlen(sendc), 0);
            printf("Servidor jogou: %d %s\n", c1.valor, c1.naipe);

            // aguardar ação do cliente: pode ser CARTA, TRUCO_PEDIDO, TRUCO_AUMENTOU, ou TRUCO_CORREU_FIM
            int b = recv(clientSock, buf, sizeof(buf)-1, 0);
            if (b <= 0) { printf("Cliente desconectou\n"); goto fim; }
            buf[b] = '\0';

            if (strncmp(buf, "TRUCO_PEDIDO:", 13) == 0) {
                // cliente pediu truco
                printf("Cliente pediu truco: %s\n", buf);
                // delegamos para negociarTruco com iniciador = 1, local index = 0 (servidor)
                int r = negociarTruco(clientSock, &pontosRodadaLocal, jogadores, 1, 0);
                if (r == 3) { printf("Cliente correu. Mão encerrada por corrida.\n"); break; }
                // após negociação, aguardar cliente jogar carta
                b = recv(clientSock, buf, sizeof(buf)-1, 0);
                if (b <= 0) { printf("Cliente desconectou\n"); goto fim; }
                buf[b] = '\0';
            }

            if (strncmp(buf, "CARTA:",6) == 0) {
                int val; char naipe[16]; int idx;
                if (sscanf(buf+6, "%d:%15[^:]:%d", &val, naipe, &idx) == 3) {
                    Carta c2; c2.valor = val; strncpy(c2.naipe, naipe, sizeof(c2.naipe)-1);
                    printf("Cliente jogou: %d %s\n", c2.valor, c2.naipe);
                    int cmp = compararCartas(c1, c2);
                    if (cmp > 0) { jogadores[0].rodadaGanha++; printf("Servidor ganhou a rodada\n"); }
                    else if (cmp < 0) { jogadores[1].rodadaGanha++; printf("Cliente ganhou a rodada\n"); }
                    else printf("Empate na rodada\n");
                }
            } else if (strncmp(buf, "TRUCO_CORREU_FIM:", 16) == 0) {
                int j, pts;
                if (sscanf(buf+16, "%d:%d", &j, &pts) == 2) {
                    jogadores[j].pontos = pts;
                    printf("Cliente informou corrida. J%d=%d\n", j+1, pts);
                    goto fim_rodadas;
                }
            }
        } // fim 3 rodadas

    fim_rodadas:
        // atribuir pontos da mão
        if (jogadores[0].rodadaGanha > jogadores[1].rodadaGanha) {
            jogadores[0].pontos += pontosRodadaLocal;
            printf("Servidor ganhou a mão e recebe %d pontos\n", pontosRodadaLocal);
        } else if (jogadores[1].rodadaGanha > jogadores[0].rodadaGanha) {
            jogadores[1].pontos += pontosRodadaLocal;
            printf("Cliente ganhou a mão e recebe %d pontos\n", pontosRodadaLocal);
        } else {
            // empate -> regra simples: ninguém recebe (ou rematch). Vamos atribuir ao iniciador (servidor) por simplicidade
            jogadores[0].pontos += pontosRodadaLocal;
            printf("Empate de rodadas -> servidor recebe %d pontos por desempate\n", pontosRodadaLocal);
        }

        // enviar placar atualizado
        snprintf(buf, sizeof(buf), "PLACAR:%d:%d", jogadores[0].pontos, jogadores[1].pontos);
        send(clientSock, buf, (int)strlen(buf), 0);

        mano++;
        // preparar nova mão se ninguém atingiu MAX_PONTOS
        if (jogadores[0].pontos >= MAX_PONTOS || jogadores[1].pontos >= MAX_PONTOS) break;

        // Reset para próxima mão: reiniciar baralho e distribuir novas cartas
        iniciandoBaralho();
        embaralharBaralho();
        distribuirMao(jogadores);
        definirVira();
        // enviar MAO e VIRA de novo
        snprintf(buf, sizeof(buf), "MAO:%d:%s:%d:%s:%d:%s",
            jogadores[1].mao[0].valor, jogadores[1].mao[0].naipe,
            jogadores[1].mao[1].valor, jogadores[1].mao[1].naipe,
            jogadores[1].mao[2].valor, jogadores[1].mao[2].naipe);
        send(clientSock, buf, (int)strlen(buf), 0);
        snprintf(buf, sizeof(buf), "VIRA:%d:%s", vira.valor, vira.naipe);
        send(clientSock, buf, (int)strlen(buf), 0);
    } // fim mãos

    // fim de jogo
    if (jogadores[0].pontos >= MAX_PONTOS) {
        snprintf(buf, sizeof(buf), "FIM:0"); // 0 = servidor venceu
        send(clientSock, buf, (int)strlen(buf), 0);
        printf("Servidor venceu o jogo!\n");
    } else {
        snprintf(buf, sizeof(buf), "FIM:1"); // 1 = cliente venceu
        send(clientSock, buf, (int)strlen(buf), 0);
        printf("Cliente venceu o jogo!\n");
    }

fim:
    printf("Fim. Pressione ENTER para fechar servidor...\n");
    getchar();
    closesocket(clientSock);
    closesocket(listenSock);
    WSACleanup();
    return 0;
}
