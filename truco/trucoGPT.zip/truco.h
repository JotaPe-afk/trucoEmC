#ifndef TRUCO_H
#define TRUCO_H

#ifdef _WIN32
#include <winsock2.h>
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
typedef int SOCKET;
#define INVALID_SOCKET (-1)
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <locale.h>

#define NUM_CARTAS 40
#define CARTAS_POR_JOGADOR 3
#define MAX_PONTOS 12  
#define MAX_BUF 1024
#define PORTA 5555

typedef struct {
    char nome[6];      // "A","2",...,"K" (simplified)
    char naipe[8];     // UTF-8 string e.g. "♥"
    int valor;         // 1..10
    int ativo;         // 1 se disponível
} Carta;

typedef struct {
    Carta mao[CARTAS_POR_JOGADOR];
    int pontos;
    int rodadaGanha;
    char nome[32];
} Jogador;

/* baralho/manilha/pontos por rodada - visíveis ao truco.c */
extern Carta baralho[NUM_CARTAS];
extern Carta vira;
extern int manilha_valor;
extern int pontosRodada;

/* funções de truco */
void iniciandoBaralho();
void embaralharBaralho();
Carta distribuirCarta();
void distribuirMao(Jogador jogadores[2]);
void mostrarMao(Jogador *j, int jogadorNum);
const char *valor_para_nome(int valor);
const char *naipe_padrao(int idx);
void gerar_arte_carta(Carta c);
void definirVira();
int compararCartas(Carta c1, Carta c2);

/* utilitários */
int lerEscolhaValidada(int min, int max);

/* negociação de truco pelo socket
   Params:
     s = socket conectado ao outro jogador
     pontosRodada = ponteiro pro valor atual da rodada (1,3,6,9,12)
     jogadores = array local (0 = servidor, 1 = cliente)
     iniciador = index do jogador que iniciou o pedido (0 ou 1)
     indexLocal = index do jogador chamando essa função (0 ou 1)
   Retorno:
     1 = aceitou (pontosRodada atualizado)
     3 = correu
     0 = erro / desconexão
*/
int negociarTruco(SOCKET s, int *pontosRodada, Jogador jogadores[2], int iniciador, int indexLocal);

#endif
